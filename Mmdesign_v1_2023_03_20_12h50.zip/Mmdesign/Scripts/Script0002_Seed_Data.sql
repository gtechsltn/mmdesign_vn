﻿SET IDENTITY_INSERT [dbo].[Test] ON 
GO
INSERT [dbo].[Test] ([Id], [Name]) VALUES (1, N'Mạnh')
GO
INSERT [dbo].[Test] ([Id], [Name]) VALUES (2, N'Vân')
GO
SET IDENTITY_INSERT [dbo].[Test] OFF